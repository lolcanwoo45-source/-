"""Exercise 3-6: repeated TCP echo messages, quit to stop."""
import argparse
import socket


def main():
    parser = argparse.ArgumentParser(description="3-6 TCP Echo client")
    parser.add_argument("--host", default="203.250.133.88", help="PuTTY server IP")
    parser.add_argument("--port", type=int, default=13333, help="Must match TCP server")
    args = parser.parse_args()

    with socket.create_connection((args.host, args.port), timeout=5) as sock:
        sock.settimeout(10)
        with sock.makefile("rb") as reader:
            while True:
                message = input("Enter message (quit to stop): ")
                if message.lower() == "quit":
                    print("Client closed")
                    break
                sock.sendall((message + "\n").encode("utf-8"))
                echoed = reader.readline(4096)
                if not echoed:
                    print("Server closed connection")
                    break
                print("Received from server:", echoed.decode("utf-8", errors="replace").rstrip("\r\n"))


if __name__ == "__main__":
    try:
        main()
    except (OSError, EOFError, KeyboardInterrupt) as exc:
        print(f"Client ended: {exc}")