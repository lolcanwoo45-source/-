"""Exercise 3-2: UDP daytime request to time-b.nist.gov:13.

For the local exercise 3-3 server, override --host and --port.
"""
import argparse
import socket


def main():
    parser = argparse.ArgumentParser(description="3-2 UDP Daytime client")
    parser.add_argument("--host", default="time-b.nist.gov", help="Daytime server hostname")
    parser.add_argument("--port", type=int, default=13, help="NIST UDP Daytime uses port 13")
    args = parser.parse_args()

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.settimeout(5)
        sock.sendto(b"What time is it?", (args.host, args.port))
        try:
            data, address = sock.recvfrom(4096)
        except socket.timeout:
            print("Timeout: external UDP/13 may be blocked or unavailable.")
            print("Try local exercise 3-3 server with --host/--port.")
            return
        print(f"Daytime from {address[0]}:{address[1]}")
        print(data.decode("ascii", errors="replace").strip())


if __name__ == "__main__":
    try:
        main()
    except OSError as exc:
        print(f"Network/DNS error: {exc}")