"""Exercise 3-3 helper: test your PuTTY UDP daytime server once."""
import argparse
import socket


def main():
    parser = argparse.ArgumentParser(description="3-3 Daytime test client")
    parser.add_argument("--host", default="203.250.133.88", help="PuTTY server IP")
    parser.add_argument("--port", type=int, default=7070, help="Must match 3-3 server")
    args = parser.parse_args()

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.settimeout(5)
        sock.sendto(b"daytime", (args.host, args.port))
        try:
            data, _ = sock.recvfrom(4096)
            print("Server local time:", data.decode("ascii", errors="replace"))
        except socket.timeout:
            print("Timeout: check server, port, firewall.")


if __name__ == "__main__":
    try:
        main()
    except OSError as exc:
        print(f"Network error: {exc}")
