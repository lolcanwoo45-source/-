"""Exercise 3-4: send an HTTP/1.1 GET request over a raw TCP socket."""
import argparse
import socket


def main():
    parser = argparse.ArgumentParser(description="3-4 HTTP GET client")
    parser.add_argument("--host", default="www.pcu.ac.kr", help="Server hostname")
    parser.add_argument("--port", type=int, default=80, help="HTTP server port")
    args = parser.parse_args()

    request = (
        f"GET / HTTP/1.1\r\n"
        f"Host: {args.host}\r\n"
        "Connection: close\r\n\r\n"
    )
    print("Request to:", args.host, args.port)
    print(request.replace("\r", "\\r").replace("\n", "\\n\n"))
    with socket.create_connection((args.host, args.port), timeout=7) as sock:
        sock.settimeout(7)
        sock.sendall(request.encode("ascii"))
        response = bytearray()
        while True:
            data = sock.recv(4096)
            if not data:
                break
            response.extend(data)
    print("===== HTTP Response =====")
    print(response.decode("utf-8", errors="replace"))


if __name__ == "__main__":
    try:
        main()
    except OSError as exc:
        print(f"HTTP request error: {exc}")