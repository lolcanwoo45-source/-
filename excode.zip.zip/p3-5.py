"""Exercise 3-5 helper: test PuTTY HTTP server without a browser."""
import argparse
import socket


def main():
    parser = argparse.ArgumentParser(description="3-5 HTTP Hello test client")
    parser.add_argument("--host", default="203.250.133.88", help="PuTTY server IP")
    parser.add_argument("--port", type=int, default=8080, help="Must match 3-5 server")
    args = parser.parse_args()

    with socket.create_connection((args.host, args.port), timeout=5) as sock:
        sock.settimeout(5)
        request = f"GET / HTTP/1.1\r\nHost: {args.host}\r\nConnection: close\r\n\r\n"
        sock.sendall(request.encode("ascii"))
        parts = []
        while True:
            chunk = sock.recv(4096)
            if not chunk:
                break
            parts.append(chunk)
    print(b"".join(parts).decode("utf-8", errors="replace"))


if __name__ == "__main__":
    try:
        main()
    except OSError as exc:
        print(f"HTTP test error: {exc}")