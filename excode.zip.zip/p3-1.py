"""Exercise 3-1: send messages repeatedly until user types quit."""
import argparse
import socket


def main():
    parser = argparse.ArgumentParser(description="3-1 UDP Echo client")
    parser.add_argument("--host", default="203.250.133.88", help="PuTTY server IP")
    parser.add_argument("--port", type=int, default=13333, help="Must match UDP server")
    args = parser.parse_args()

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.settimeout(5)
        while True:
            message = input("Enter message (quit to stop): ")
            if message.lower() == "quit":
                print("Client closed")
                break
            sock.sendto(message.encode("utf-8"), (args.host, args.port))
            try:
                data, server_address = sock.recvfrom(4096)
                print(f"Received from server: {data.decode('utf-8', errors='replace')}")
            except socket.timeout:
                print("No response within 5 seconds. Check server, port, firewall.")


if __name__ == "__main__":
    try:
        main()
    except (OSError, EOFError, KeyboardInterrupt) as exc:
        print(f"Client ended: {exc}")